#Instala Librerias
install.packages("neonUtilities")
install.packages("plyr")
install.packages("rstudioapi")
install.packages('hemispheR')

#Carga Librerias
library(neonUtilities)
library(plyr)
library(rstudioapi)
library(hemispheR)


#Consigure direccion de la carpeta donde esta el codigo R
file_path <- normalizePath(rstudioapi::getActiveDocumentContext()$path)
script_dir <- dirname(file_path)
print(script_dir)

dest_file <- file.path(script_dir, "D16_9469.NEF")
cmd <- sprintf('magick mogrify -contrast-stretch 1x99%% -format jpg "%s"', dest_file)
system(cmd)
dest_jpg <- file.path(script_dir, "D16_9469.jpg")
dest_jpg2 <- file.path(script_dir, "D16_9469_with_ring.jpg")

img<-import_fisheye(dest_jpg,
                    circular=FALSE,
                    gamma=1,
                    display=TRUE,
                    message=TRUE)

img.bw<-binarize_fisheye(img,
                         method='Otsu',
                         zonal=FALSE,
                         manual=NULL,
                         display=FALSE,
                         export=FALSE)

jpeg(dest_jpg2)
gap.frac<-gapfrac_fisheye(
  img.bw,
  maxVZA = 90,
  lens = "FC-E8",
  startVZA = 0,
  endVZA = 70,
  nrings = 7,
  nseg = 8,
  display = TRUE,
  message = TRUE)
dev.off()
graphics.off()

#El codigo importante.
gap_frac_foot <- gap.frac[, !names(gap.frac) %in% c("GF45_90", "GF90_135")]

canopy_foot<-canopy_fisheye(gap_frac_foot)

canopy<-canopy_fisheye(gap.frac)

